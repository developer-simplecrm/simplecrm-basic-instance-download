# SugarCRMCustomQueries

This module has two main features:

1. To make advanced queries direct to database (like PhpMyAdmin)
2. To make remotely queries (from other apps) to your CRM via web services and receive data in JSON format

Documentation available here:
[www.sugarqueries.com](http://www.sugarqueries.com)

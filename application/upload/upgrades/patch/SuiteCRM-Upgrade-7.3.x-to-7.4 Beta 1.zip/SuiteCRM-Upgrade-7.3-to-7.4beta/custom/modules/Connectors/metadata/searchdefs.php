<?php
// created: 2014-02-03 12:55:31
$searchdefs = array (
  'ext_rest_insideview' => 
  array (
    'Accounts' => 
    array (
    ),
    'Contacts' => 
    array (
    ),
    'Leads' => 
    array (
    ),
    'Opportunities' => 
    array (
    ),
  ),
  'ext_rest_twitter' => 
  array (
    'Accounts' => 
    array (
    ),
    'Leads' => 
    array (
    ),
  ),
  'ext_rest_facebook' => 
  array (
    'Accounts' => 
    array (
    ),
    'Contacts' => 
    array (
    ),
    'Leads' => 
    array (
    ),
  ),
);
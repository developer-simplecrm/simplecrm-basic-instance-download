<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.detail.php');

class FavoritesViewDetail extends ViewDetail {
	function FavoritesViewDetail(){
 		parent::ViewDetail();
 	}
	
}
?>

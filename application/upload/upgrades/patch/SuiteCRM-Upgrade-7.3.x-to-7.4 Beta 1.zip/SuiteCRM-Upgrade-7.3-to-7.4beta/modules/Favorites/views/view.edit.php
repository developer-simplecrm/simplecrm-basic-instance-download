<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');

require_once('include/MVC/View/views/view.edit.php');

class FavoritesViewEdit extends ViewEdit {
	function FavoritesViewEdit(){
 		parent::ViewEdit();
 	}
	
	function display(){
		parent::display();
	}

}
?>

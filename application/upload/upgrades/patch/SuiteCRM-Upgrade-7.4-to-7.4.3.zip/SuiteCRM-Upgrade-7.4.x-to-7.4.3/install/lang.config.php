<?php 

// ADDITIONAL LANGUAGES
$config['languages'] = array(
	'es_es'	=> 'Español (ES)',
);

?>
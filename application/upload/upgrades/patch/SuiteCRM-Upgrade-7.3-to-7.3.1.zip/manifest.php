<?php
$manifest = array (
  'acceptable_sugar_flavors' => 
  array (
    0 => 'CE',
  ),
  'acceptable_sugar_versions' => 
  array (
    'exact_matches' => 
    array (
      0 => '6.5.20'
    ),
    'regex_matches' => 
    array (
    ),
  ),
  'author' => 'SalesAgility',
  'copy_files' => 
  array (
    'from_dir' => 'SuiteCRM-Upgrade-7.3-to-7.3.1',
    'to_dir' => '',
    'force_copy' => 
    array (
    ),
  ),
  'description' => '',
  'icon' => '',
  'is_uninstallable' => true,
  'offline_client_applicable' => true,
  'name' => 'SuiteCRM',
  'published_date' => '2015-08-25 17:00:00',
  'type' => 'patch',
  'version' => '7.3.1',
);
?>

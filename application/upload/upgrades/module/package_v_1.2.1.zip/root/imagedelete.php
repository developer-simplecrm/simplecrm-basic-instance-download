<?php

if(!defined('sugarEntry')) define('sugarEntry', true);
require_once('include/entryPoint.php');
require_once('config.php');
global $db, $sugar_config;
$path= $_POST['path'];
$id= $_POST['id'];

if(empty($id))
{
$id=$_POST['module_id'];	
}
$field= $_POST['field'];
$module= strtolower($_POST['module']);
$full_path=$_POST['path'].$id."_".$field;



$result = $db->query("UPDATE ".$module."_cstm SET ".$field."='' WHERE id_c='".$id."'");
 
if($result) {
if(!empty($_POST['path'])) {
	unlink($full_path);
	echo $f_result="true";
}
}else
{
	$result2 = $db->query("UPDATE ".$module." SET ".$field."='' WHERE id='".$id."'");
	if($result2) {
	if(!empty($_POST['path'])) {
	unlink($full_path);
	echo $f_result="true";
	}
}
}

?>

<?php
// created: 2016-06-08 10:51:18
$dictionary["scrm_Partner_Contacts"]["fields"]["scrm_partner_contacts_leads"] = array (
  'name' => 'scrm_partner_contacts_leads',
  'type' => 'link',
  'relationship' => 'scrm_partner_contacts_leads',
  'source' => 'non-db',
  'module' => 'Leads',
  'bean_name' => 'Lead',
  'side' => 'right',
  'vname' => 'LBL_SCRM_PARTNER_CONTACTS_LEADS_FROM_LEADS_TITLE',
);
